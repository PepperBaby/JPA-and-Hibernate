package com.cg.service;


import java.util.List;

import com.cg.dto.Book;

public interface LibraryService {

	List<Book> getAllBooks();
	List<Book> fetchBookInPriceRange(double min, double max);
}
