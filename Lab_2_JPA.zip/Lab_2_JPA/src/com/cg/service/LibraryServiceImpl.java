package com.cg.service;


import java.util.List;

import com.cg.dao.LibraryDao;
import com.cg.dao.LibraryDaoImpl;
import com.cg.dto.Book;

public class LibraryServiceImpl implements LibraryService {

	LibraryDao libDao = new LibraryDaoImpl();
	@Override
	public List<Book> getAllBooks() {
		
		return libDao.getAllBooks();
	}

	@Override
	public List<Book> fetchBookInPriceRange(double min, double max) {
		
		return libDao.fetchBookInPriceRange(min, max);
	}

}
