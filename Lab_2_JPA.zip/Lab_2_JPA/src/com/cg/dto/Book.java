package com.cg.dto;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="book1")
public class Book implements Serializable{

	private static final long serialVersionUID = 1L;
	@Id
	private int ISBN;
	private String bookTitle;
	@Column(name="bookprice")
	private double bookPrice;
	
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "library", 
	joinColumns = { @JoinColumn(name = "book_id") }, //maps to current id table
	inverseJoinColumns = { @JoinColumn(name = "author_Id") })
	private Set<Author> author = new HashSet<>();
	
	public Set<Author> getAuthor() {
		return author;
	}
	public void setAuthor(Set<Author> author) {
		this.author = author;
	}
	public int getISBN() {
		return ISBN;
	}
	public void setISBN(int iSBN) {
		ISBN = iSBN;
	}
	public String getBookTitle() {
		return bookTitle;
	}
	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}
	public double getBookPrice() {
		return bookPrice;
	}
	public void setBookPrice(double bookPrice) {
		this.bookPrice = bookPrice;
	}
	@Override
	public String toString() {
		return "book [ISBN=" + ISBN + ", bookTitle=" + bookTitle
				+ ", bookPrice=" + bookPrice + "]";
	}
	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Book(int iSBN, String bookTitle, double bookPrice) {
		super();
		ISBN = iSBN;
		this.bookTitle = bookTitle;
		this.bookPrice = bookPrice;
	}
	public void addAuthor(Author author) {
		this.getAuthor().add(author);
	}
	
	
}
