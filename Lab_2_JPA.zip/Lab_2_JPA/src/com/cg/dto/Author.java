package com.cg.dto;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
@Entity
@Table(name="author1")
public class Author implements Serializable{
	private static final long serialVersionUID = 1L;
	@Id
	private int authorId;
	private String authorName;
	
	@ManyToMany(fetch=FetchType.LAZY,mappedBy="author")
	private Set<Book> book = new HashSet<>();
	
	public Set<Book> getBook() {
		return book;
	}
	public void setBook(Set<Book> book) {
		this.book = book;
	}
	public int getAuthorId() {
		return authorId;
	}
	public void setAuthorId(int authorId) {
		this.authorId = authorId;
	}
	public String getAuthorName() {
		return authorName;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	public Author() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "author [authorId=" + authorId + ", authorName=" + authorName
				+ "]";
	}
	
	
}
