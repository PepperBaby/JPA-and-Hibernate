package com.cg.ui;


import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.dto.Author;
import com.cg.dto.Book;
import com.cg.service.LibraryService;
import com.cg.service.LibraryServiceImpl;

public class LibraryClient {

	public static void main(String[] args) {
		LibraryService libSer = new LibraryServiceImpl();
		Scanner sc = new Scanner(System.in);
		int choice;
		do{
			System.out.println(" 1. Search All Book"
					+ "\n 2. "
					+ "\n 3. Search All Book on price range"
					+ "\n 4."
					+ "\n 5. Exit");
			System.out.println("Enter Your Choice: ");
			choice = sc.nextInt();
			switch(choice){
			case 1:
				List<Book> bookList = libSer.getAllBooks();
				for(Book book:bookList)
				{
					System.out.println(book);
				}
				break;
				
			case 2:
				EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("JPA-PU");
				EntityManager em = factory.createEntityManager();
				em.getTransaction().begin();
				
				Author author = new Author();
				author.setAuthorId(1001);
				author.setAuthorName("Babitha");
				
				Author author1 = new Author();
				author1.setAuthorId(1002);
				author1.setAuthorName("Jyoti");
				
				Author author2 = new Author();
				author2.setAuthorId(1003);
				author2.setAuthorName("Kitty");
				
				Book book = new Book();
				book.setISBN(963);
				book.setBookTitle("Maths");
				book.setBookPrice(1234);
				
				book.addAuthor(author);
				book.addAuthor(author1);
				
				Book book1 = new Book();
				book1.setISBN(852);
				book1.setBookTitle("Physics");
				book1.setBookPrice(7894);
				
				
				book1.addAuthor(author);
				book1.addAuthor(author2);
				em.persist(book);
				em.persist(book1);
				
				System.out.println("Added authors along with book details to database.");
				em.getTransaction().commit();
				em.close();
				factory.close();

				break;
				
				
			case 3:
				System.out.println("Enter Min price");
				double minPrice = sc.nextInt();
				System.out.println("Enter Max price");
				double maxPrice = sc.nextInt();
				List<Book> bList = libSer.fetchBookInPriceRange(minPrice, maxPrice);
				for(Book b:bList)
				{
					System.out.println(b);
				}
				break;
				
			case 4:
				
				break;
				
			case 5:
				System.exit(0);
				break;
			}
		}while(true);

	}

}
