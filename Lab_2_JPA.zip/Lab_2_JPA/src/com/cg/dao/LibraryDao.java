package com.cg.dao;


import java.util.List;

import com.cg.dto.Book;

public interface LibraryDao {

	List<Book> getAllBooks();
	List<Book> fetchBookInPriceRange(double min, double max);
}
