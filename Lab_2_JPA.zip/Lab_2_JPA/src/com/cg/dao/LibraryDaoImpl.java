package com.cg.dao;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.dto.Book;

public class LibraryDaoImpl implements LibraryDao {

	EntityManager em;
	public LibraryDaoImpl() {
		super();
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-PU");
		em = emf.createEntityManager();
	}
	@Override
	public List<Book> getAllBooks() {
		
		TypedQuery<Book> query = em.createQuery("SELECT b FROM Book b", Book.class);
		return query.getResultList();
	}

	@Override
	public List<Book> fetchBookInPriceRange(double min, double max) {
		String jpql = "SELECT b FROM Book b WHERE b.bookPrice BETWEEN :min AND :max";
		TypedQuery<Book> query = em.createQuery(jpql, Book.class);
		query.setParameter("min", min);
		query.setParameter("max", max);
		return query.getResultList();
		
		
	}

}
