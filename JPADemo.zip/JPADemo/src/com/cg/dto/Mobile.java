package com.cg.dto;

import javax.persistence.Column; //JPA annotations require persistence import
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="mobiles")
public class Mobile {

	@Id
	private int mobileid;
	
	@Column(name="name")
	private String mname;
	
	private double price;
	
	@Column(name="quantity")
	private int qty;
	
	//Getter and Setters
	public int getMobileid() {
		return mobileid;
	}
	public void setMobileid(int mobileid) {
		this.mobileid = mobileid;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	
	//Constructors
	public Mobile() {
		super();
	}
	public Mobile(int mobileid, String mname, double price, int qty) {
		super();
		this.mobileid = mobileid;
		this.mname = mname;
		this.price = price;
		this.qty = qty;
	}
	
}
