package com.cg.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.dto.Mobile;
import com.cg.service.MobileService;
import com.cg.service.MobileServiceImpl;

public class MobileClient {

	public static void main(String[] args) {
		MobileService mser = new MobileServiceImpl();
		Scanner sc = new Scanner(System.in);
		int choice;
		do{
			System.out.println(" 1. Add Mobile"
					+ "\n 2. Update Mobile"
					+ "\n 3. Search Mobile"
					+ "\n 4. Delete Mobile"
					+ "\n 5. Search All Mobile"
					+ "\n 6. Search All Mobile on price range"
					+ "\n 7. Exit");
			System.out.println("Enter Your Choice: ");
			choice = sc.nextInt();
			switch(choice){
			case 1:
				System.out.println("Enter Mobile Name: ");
				sc.nextLine();
				String mname = sc.nextLine();
				System.out.println("Enter price: ");
				double price = sc.nextDouble();
				System.out.println("Enter quantity: ");
				int qty = sc.nextInt();
				
				Mobile mobile = new Mobile();
				mobile.setMname(mname);
				mobile.setPrice(price);
				mobile.setQty(qty);
				
				mser.addMobile(mobile);
				System.out.println("Mobile details added.");
				
				break;

			case 2:
				System.out.println("Enter mobile id to change its quantity ");
				int mid2 = sc.nextInt();
				System.out.println("Enter no of mobiles purchased");
				int Qty = sc.nextInt();
				Mobile mobile3 = mser.findMobile(mid2);
				int availableQty = mobile3.getQty();
				int updatedQty = availableQty - Qty;
				mobile3.setQty(updatedQty);
				mser.updateMobile(mobile3);
				System.out.println("Mobile details updated");
				break;
				
			case 3:
				System.out.println("Enter mobile id to search: ");
				int mid =sc.nextInt();
				Mobile mobile1 = mser.findMobile(mid);
				System.out.println(mobile1);
				break;
				
			case 4:
				System.out.println("Enter mobile id to search: ");
				int mid1 =sc.nextInt();
				Mobile mobile2 = mser.findMobile(mid1);
				System.out.println(mobile2);
				mser.deleteMobile(mobile2);
				System.out.println("Mobile details deleted.");
				break;
				
			case 5:
				List<Mobile> mobList = mser.getAllMobiles();
				for(Mobile mob:mobList)
				{
					System.out.println(mob);
				}
				break;
				
			case 6:
				System.out.println("Enter Min price");
				double minPrice = sc.nextDouble();
				System.out.println("Enter Max price");
				double maxPrice = sc.nextDouble();
				List<Mobile> mList = mser.fetchMobileInPriceRange(minPrice, maxPrice);
				for(Mobile m:mList)
				{
					System.out.println(m);
				}
				break;				
			case 7: 
				System.exit(0);
				break;
			}
		}
		while(true);
		
		
	}

}
