package com.cg.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
public class Author {
 /*
  *  Name                                      Null?    Type
 ----------------------------------------- -------- -----------------

 AUTHOR_ID                                 NOT NULL NUMBER
 FIRST_NAME                                         VARCHAR2(10)
 MIDDLE_NAME                                        VARCHAR2(10)
 LAST_NAME                                          VARCHAR2(10)
 PHONE_NO                                           NUMBER(10)

  */
	@Id
	@SequenceGenerator(name="authorSeq",allocationSize=1,sequenceName="author_id_seq")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="authorSeq")
	@Column(name="author_id")
	private int authorId;
	
	@Column(name="first_name")
	private String firstName;
	
	@Column(name="middle_name")
	private String middleName;
	
	@Column(name="last_name")
	private String lastName;
	
	@Column(name="phone_no")
	private long phoneNo;
	
	public int getAuthorId() {
		return authorId;
	}
	public void setAuthorId(int authorId) {
		this.authorId = authorId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public Author() {
		super();
	}
	public Author(int authorId, String firstName, String middleName,
			String lastName, long phoneNo) {
		super();
		this.authorId = authorId;
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.phoneNo = phoneNo;
	}
	@Override
	public String toString() {
		return "Author [authorId=" + authorId + ", firstName=" + firstName
				+ ", middleName=" + middleName + ", lastName=" + lastName
				+ ", phoneNo=" + phoneNo + "]";
	}
	
	
}
