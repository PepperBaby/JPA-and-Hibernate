package com.cg.service;

import com.cg.dao.AuthorDao;
import com.cg.dao.AuthordaoImpl;
import com.cg.dto.Author;

public class AuthorServiceImpl implements AuthorService {

	AuthorDao authDao = new AuthordaoImpl();
	
	@Override
	public void addAuthor(Author author) {
		authDao.addAuthor(author);

	}

	@Override
	public void updateAuthor(Author author) {
		authDao.updateAuthor(author);
	}

	@Override
	public void deleteAuthor(Author author) {
		authDao.deleteAuthor(author);

	}

	@Override
	public Author findAuthor(int authorId) {
		
		return authDao.findAuthor(authorId);
	}

}
