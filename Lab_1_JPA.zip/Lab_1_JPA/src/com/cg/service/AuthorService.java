package com.cg.service;

import com.cg.dto.Author;

public interface AuthorService {

	void addAuthor(Author author);
	void updateAuthor(Author author);
	void deleteAuthor(Author author);
	Author findAuthor(int authorId);

}
