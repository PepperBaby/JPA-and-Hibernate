package com.cg.ui;

import java.util.Scanner;

import com.cg.dto.Author;
import com.cg.service.AuthorService;
import com.cg.service.AuthorServiceImpl;

public class AuthorDetails {

	public static void main(String[] args) {
		AuthorService authSer = new AuthorServiceImpl();
		Scanner sc = new Scanner(System.in);
		int choice;
		do{
			System.out.println(" 1. Add Author"
					+ "\n 2. Update Author"
					+ "\n 3. Search Author"
					+ "\n 4. Delete Author"
					+ "\n 5. Exit");
			System.out.println("Enter Your Choice: ");
			choice = sc.nextInt();
			switch(choice){
			case 1:
				System.out.println("Enter author first name: ");
				String fName = sc.next();
				System.out.println("Enter middle name: ");
				String mName = sc.next();
				System.out.println("Enter last  name: ");
				String lName = sc.next();
				System.out.println("Enter phone number: ");
				long phoneNo = sc.nextLong();
				
				Author author = new Author();
				author.setFirstName(fName);
				author.setMiddleName(mName);
				author.setLastName(lName);
				author.setPhoneNo(phoneNo);
				
				authSer.addAuthor(author);
				System.out.println("Author details entered!");
				break;
				
			case 2:
				System.out.println("Enter author id to change details entered ");
				int aid2 = sc.nextInt();
				System.out.println("Enter first name to change");
				String fName1 = sc.next();
				System.out.println("Enter middle name to change");
				String mName1 = sc.next();
				System.out.println("Enter last name to change");
				String lName1 = sc.next();
				System.out.println("Enter phone number to change");
				long phoneNo1 = sc.nextLong();
				
				Author author3 = authSer.findAuthor(aid2);
				author3.setFirstName(fName1);
				author3.setMiddleName(mName1);
				author3.setLastName(lName1);
				author3.setPhoneNo(phoneNo1);
				
				authSer.updateAuthor(author3);
				System.out.println("Author details updated");
				
				break;
				
			case 3:
				System.out.println("Enter author id to search: ");
				int aid =sc.nextInt();
				Author author1 = authSer.findAuthor(aid);
				System.out.println(author1);
				
				break;
				
			case 4:
				System.out.println("Enter author id to search: ");
				int aid1 =sc.nextInt();
				Author author2 = authSer.findAuthor(aid1);
				System.out.println(author2);
				authSer.deleteAuthor(author2);
				System.out.println("Author details deleted.");
				
				break;
				
			case 5: System.exit(0);
				break;
			
			}
		}while(true);

	}

}
