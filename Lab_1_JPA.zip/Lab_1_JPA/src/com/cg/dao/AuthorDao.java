package com.cg.dao;

import com.cg.dto.Author;



public interface AuthorDao {
	void addAuthor(Author author);
	void updateAuthor(Author author);
	void deleteAuthor(Author author);
	Author findAuthor(int authorId);
}
