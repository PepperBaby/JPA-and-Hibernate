package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.dto.Author;

public class AuthordaoImpl implements AuthorDao {

	EntityManager em;
	
	public AuthordaoImpl() {
		super();
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-PU");
		em = emf.createEntityManager();
	}

	@Override
	public void addAuthor(Author author) {
		em.getTransaction().begin();
		em.persist(author);
		em.getTransaction().commit();
	}

	@Override
	public void updateAuthor(Author author) {
		em.getTransaction().begin();
		em.merge(author);
		em.getTransaction().commit();
	}

	@Override
	public void deleteAuthor(Author author) {
		em.getTransaction().begin();
		em.remove(author);
		em.getTransaction().commit();
	}

	@Override
	public Author findAuthor(int authorId) {
		Author author = em.find(Author.class, authorId);
		return author;
	}

}
